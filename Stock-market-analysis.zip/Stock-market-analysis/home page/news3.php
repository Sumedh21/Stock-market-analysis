<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <title>SNAP-Trading About us</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="bg-top navbar-light">
      <div class="container">
        <div class="row no-gutters d-flex align-items-center align-items-stretch">
          <div class="col-md-4 d-flex align-items-center py-4">
            <a class="navbar-brand" href="index.html">SNAP - Trading</a>
          </div>
          <div class="col-lg-8 d-block">
            <div class="row d-flex">
              <div class="col-md d-flex topper align-items-center align-items-stretch py-md-4">
                <div class="icon d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
                <div class="text">
                  <span>Email</span>
                  <span>snap_trading@gmail.com</span>
                </div>
              </div>
              <div class="col-md d-flex topper align-items-center align-items-stretch py-md-4">
                <div class="icon d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
                <div class="text">
                  <span>Call</span>
                  <span>Call Us: +91 797 255 3580</span>
                </div>
              </div>
              <div class="col-md topper d-flex align-items-center justify-content-end">
                <p class="mb-0 d-block">
                  <a href="#" class="btn py-2 px-3 btn-primary">
                    <span>Stock and Commodities</span>
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>



        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item"><a href="homepage.php" class="nav-link pl-0">Home</a></li>
                     <li class="nav-item "><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="reg-stock.php" class="nav-link">Stock</a></li>
            <li class="nav-item"><a href="portfolio.php" class="nav-link">Portfolio</a></li>
            <li class="nav-item"><a href="reg-news.php" class="nav-link">News</a></li>
            <li class="nav-item"><a href="reg-cryptocurrency.php" class="nav-link">Crypto-Currency</a></li>
            <li class="nav-item"><a href="reg-where_to_invest.php" class="nav-link">Analysis</a></li>
               <li class="nav-item"><a href="Logout.php" class="nav-link">Logout</a></li>

          </ul>
        </div>
      </div>
    </nav>
    <section style="padding-right: 25%; padding-top: 5%; padding-left:25%; height:50%; width: 70%"><img src="news/n3.jpg" ></section>
    <section style="padding-left:20%; padding-top: 5%; padding-right:20%; font:Arial;" >
      <h5>
      Prime Minister Narendra Modi launched the Make in India initiative on September 25, 2014, with the primary goal of making India a global manufacturing hub, by encouraging both multinational as well as domestic companies to manufacture their products within the country. Led by the Department of Industrial Policy and Promotion, the initiative aims to raise the contribution of the manufacturing sector to 25% of the Gross Domestic Product (GDP) by the year 2025 from its current 16%. Make in India has introduced multiple new initiatives, promoting foreign direct investment, implementing intellectual property rights and developing the manufacturing sector.<br>

It targets 25 sectors of the economy which range from automobile to Information Technology (IT) & Business Process Management (BPM), the details of each can be viewed on the official site (www.makeinindia.com).<br>

It also seeks to facilitate job creation, foster innovation, enhance skill development and protect intellectual property. The logo of ‘Make in India’ – a lion made of gear wheels – itself reflects the integral role of manufacturing in government’s vision and national development. The initiative is built on four pillars which are as follows:<br>

New Processes: The government is introducing several reforms to create possibilities for getting Foreign Direct Investment (FDI) and foster business partnerships. Some initiatives have already been undertaken to alleviate the business environment from outdated policies and regulations. This reform is also aligned with parameters of World Bank's 'Ease of Doing Business' index to improve India's ranking on it.New Infrastructure: Infrastructure is integral to the growth of any industry. The government intends to develop industrial corridors and build smart cities with state-of-the-art technology and high-speed communication. Innovation and research activities are supported by a fast-paced registration system and improved infrastructure for Intellectual Property Rights (IPR) registrations. Along with the development of infrastructure, the training for the skilled workforce for the sectors is also being addressed.New Sectors: ‘Make in India’ has identified 25 sectors to promote with the detailed information being shared through an interactive web-portal.1 The Government has allowed 100% FDI in Railway2and removed restrictions in Construction.3 It has also recently increased the cap of FDI to 100% in Defense and Pharmaceutical.4New Mindset: Government in India has always been seen as a regulator and not a facilitator. This initiative intends to change this by bringing a paradigm shift in the way Government interacts with various industries. It will focus on acting as a partner in the economic development of the country alongside the corporate sector.<br>
Since the launch of Make in India in September 2014, FDI inflows of USD 77 billion including a equity inflows of USD 56 billion has been received for the period October 2014 to March 2016. This represents about a 44% increase in FDI Equity inflows over the same corresponding period.<br>

‘Zero defect zero effect’ is a key phrase which has come to be associated with the Make in India campaign. In the words of Prime Minister Narendra Modi, “Let’s think about making our product which has 'zero defect'… and 'zero effect' so that the manufacturing does not have an adverse effect on our environment".5 Thus, sustainable development in the country is being made possible by imposing high-quality manufacturing standards while minimising environmental and ecological impact.<br>

Within the short span of time, there are many instances of the initiative’s success. In December 2015, Micromax announced that it would put up three new manufacturing units in Rajasthan, Telangana and Andhra Pradesh. Japan announced it would set up a USD 12 billion fund for Make in India-related projects, called the “Japan-India Make-in-India Special Finance Facility” after the Japanese Prime Minister Shinzo Abe’s visit to the country. Huawei opened a new Research and Development (R&D) campus in Bengaluru and is in the process of setting up a telecom hardware manufacturing plant in Chennai. France-based LH Aviation signed a Memorandum of Understanding (MoU) with OIS Advanced Technologies to set up a manufacturing facility in India for producing drones. Foxconn announced it would invest USD 5 billion over five years for R&D and creating a hi-tech semiconductor manufacturing facility in Maharashtra. Samsung said it would manufacture the Samsung Z1 in its plant in Noida while General Motors declared that it would invest USD 1 billion to begin producing automobiles in the capital state.6And this is only the tip of the iceberg as there are many more proposals in the pipeline.<br><br>

“Come make in India. Sell anywhere, [but] make in India.” Prime Minister Narendra Modi said while introducing his vision to the public. And it seems that the world is more than ready to embrace this vision, which is already set on a path to become a reality.
<br><br>
 

Citations:
1. http://www.makeinindia.com/home
2. http://trak.in/tags/business/2014/11/13/indian-railways-100-fdi/
3. http://economictimes.indiatimes.com/wealth/personal-finance-news/government-eases-fdi-norms-for-construction-sector/articleshow/49739407.cms
4. http://www.thehindu.com/news/national/modi-reviews-fdi-policy/article8751860.ece
5. http://www.zed.org.in/
6. http://www.business-standard.com/article/economy-policy/make-in-india-the-story-so-far-116021200338_1.html


</h5>
    </section>
	
    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">G. H. Raisoni college,Wagholi,Pune</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+91 797 255 3580</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">snap_trading@gamil.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>



&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5 ml-md-4">
              <h2 class="ftco-heading-2">Links</h2>
              <ul class="list-unstyled">
                <li><a href="homepage.php"><span class="ion-ios-arrow-round-forward mr-2"></span>Home</a></li><br>
                <li><a href="reg-about.php"><span class="ion-ios-arrow-round-forward mr-2"></span>About</a></li><br>
                <li><a href="portfolio.php"><span class="ion-ios-arrow-round-forward mr-2"></span>Portfolio</a></li><br>
                <li><a href="news"><span class="ion-ios-arrow-round-forward mr-2"></span>Blog</a></li>
                <br><li><a href="https://www.instagram.com/nishad_joshi_/"><span class="ion-ios-arrow-round-forward mr-2"></span>Contact</a></li><br>
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2">Subscribe Us!</h2>
              <form action="#" class="subscribe-form">
                <div class="form-group">
                  <input type="text" class="form-control mb-2 text-center" placeholder="Enter email address">
                  <input type="submit" value="Subscribe" class="form-control submit px-3">
                </div>
              </form>
              
            </div>
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2 mb-0">Connect With Us</h2>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/nishad.joshi.33"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.instagram.com/nishad_joshi_/"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

           
          </div>
        </div>
      </div>
    </footer>
    
  
