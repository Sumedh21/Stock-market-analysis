<?php
session_start();
?>



<!DOCTYPE html>
<html lang="en">
  <head>
    <title>SNAP-Trading About us</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>
    <div class="bg-top navbar-light">
      <div class="container">
        <div class="row no-gutters d-flex align-items-center align-items-stretch">
          <div class="col-md-4 d-flex align-items-center py-4">
            <a class="navbar-brand" href="index.html">SNAP - Trading</a>
          </div>
          <div class="col-lg-8 d-block">
            <div class="row d-flex">
              <div class="col-md d-flex topper align-items-center align-items-stretch py-md-4">
                <div class="icon d-flex justify-content-center align-items-center"><span class="icon-paper-plane"></span></div>
                <div class="text">
                  <span>Email</span>
                  <span>snap_trading@gmail.com</span>
                </div>
              </div>
              <div class="col-md d-flex topper align-items-center align-items-stretch py-md-4">
                <div class="icon d-flex justify-content-center align-items-center"><span class="icon-phone2"></span></div>
                <div class="text">
                  <span>Call</span>
                  <span>Call Us: +91 797 255 3580</span>
                </div>
              </div>
              <div class="col-md topper d-flex align-items-center justify-content-end">
                <p class="mb-0 d-block">
                  <a href="#" class="btn py-2 px-3 btn-primary">
                    <span>Stock and Commodities</span>
                  </a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>



         <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item"><a href="homepage.php" class="nav-link pl-0">Home</a></li>
                     <li class="nav-item"><a href="about.php" class="nav-link">About</a></li>
            <li class="nav-item"><a href="reg-stock.php" class="nav-link">Stock</a></li>
            <li class="nav-item"><a href="portfolio.php" class="nav-link">Portfolio</a></li>
            <li class="nav-item"><a href="reg-news.php" class="nav-link">News</a></li>
            <li class="nav-item"><a href="reg-cryptocurrency.php" class="nav-link">Crypto-Currency</a></li>
            <li class="nav-item"><a href="reg-where_to_invest.php" class="nav-link">Analysis</a></li>
               <li class="nav-item"><a href="Logout.php" class="nav-link">Logout</a></li>

          </ul>
        </div>
      </div>
    </nav>
    <section style="padding-right: 25%; padding-top: 5%; padding-left:25%; height:50%; width: 70%"><img src="news/n2.gif" ></section>
    <section style="padding-left:20%; padding-top: 5%; padding-right:20%; font:Arial;">
      <h5>
     Maruti Suzuki India Ltd said on Wednesday that it will suspend vehicle production at its plants in Gurugram and Manesar as the automaker battles an unprecedented slowdown in sales.<br>

India’s largest passenger vehicle maker by sales will shut the two plants on Saturday and Monday, according to a company statement. This will be the first time the company will close both plants simultaneously for two days in its more than three decades long presence in India.<br>

The step is an indication that the Suzuki Motor Corp. unit expects sales to remain weak even during the crucial festive season. The production shutdown is exceptional as Maruti tends to keep its factories at optimum levels in the run up to the festivals.<br>


India’s auto industry has been in the grip of a prolonged slowdown.<br>

Most passenger vehicle manufacturers have been cutting production as sales fell for the 10th consecutive month in August. Maruti cut production by a third in August, for the seventh straight month. Vehicle production at Maruti’s three plants, including the one in Gujarat, plunged 34% year-on-year (y-o-y) to 111,370 units in August.<br>

Automakers traditionally boost vehicle production ahead of the festive months of September through October-November, as sales during the festival season constitute almost a third of the vehicles sold during the year.<br>

This year, expecting a muted response from customers, other manufacturers such as Hyundai Motor India Ltd and Mahindra and Mahindra Ltd reported a double-digit decline in wholesale dispatches to dealerships in July and August before the festive season kicked off with Ganesh Chaturthi in the western states, which will be followed by Onam on 12 September in southern states, especially Kerala.
<br>

Maruti’s domestic wholesales in August fell 36% y-o-y to 94,728 units. This is the third time the firm has dispatched fewer than 100,000 vehicles to its dealerships in a particular month since July 2017. Vehicles dispatched by the top six passenger manufacturers fell 34% y-o-y in August to 171,193 vehicles.<br>

Taking a cue from the companies, dealers have also turned cautious in adding to their vehicle stocks. Ashish Kale, president, Federation of Automobile Dealers Associations (Fada), said sales during the festival season are expected to remain flat or grow marginally, compared to last year.<br>
</h5>
    </section>
		

    <footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2">Have a Questions?</h2>
              <div class="block-23 mb-3">
                <ul>
                  <li><span class="icon icon-map-marker"></span><span class="text">G. H. Raisoni college,Wagholi,Pune</span></li>
                  <li><a href="#"><span class="icon icon-phone"></span><span class="text">+91 797 255 3580</span></a></li>
                  <li><a href="#"><span class="icon icon-envelope"></span><span class="text">snap_trading@gamil.com</span></a></li>
                </ul>
              </div>
            </div>
          </div>



&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5 ml-md-4">
              <h2 class="ftco-heading-2">Links</h2>
              <ul class="list-unstyled">
                <li><a href="homepage.php"><span class="ion-ios-arrow-round-forward mr-2"></span>Home</a></li><br>
                <li><a href="reg-about.php"><span class="ion-ios-arrow-round-forward mr-2"></span>About</a></li><br>
                <li><a href="portfolio.php"><span class="ion-ios-arrow-round-forward mr-2"></span>Portfolio</a></li><br>
                <li><a href="news"><span class="ion-ios-arrow-round-forward mr-2"></span>Blog</a></li>
                <br><li><a href="https://www.instagram.com/nishad_joshi_/"><span class="ion-ios-arrow-round-forward mr-2"></span>Contact</a></li><br>
              </ul>
            </div>
          </div>
          <div class="col-md-6 col-lg-3">
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2">Subscribe Us!</h2>
              <form action="#" class="subscribe-form">
                <div class="form-group">
                  <input type="text" class="form-control mb-2 text-center" placeholder="Enter email address">
                  <input type="submit" value="Subscribe" class="form-control submit px-3">
                </div>
              </form>
              
            </div>
            <div class="ftco-footer-widget mb-5">
              <h2 class="ftco-heading-2 mb-0">Connect With Us</h2>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-3">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="https://www.facebook.com/nishad.joshi.33"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="https://www.instagram.com/nishad_joshi_/"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

           
          </div>
        </div>
      </div>
    </footer>
    
  
