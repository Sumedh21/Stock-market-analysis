<?php
session_start();
?>

<script src="http://feeds.financialcontent.com/JSQuote?Ticker=BSE+NSE"></script>
<meta charset="utf-8" http-equiv="refresh" content="">

  <head>
    <title>ANALYSIS</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>





<body style=" background-color:white; background-size: 100% 100%;">

  <section style="background-color: white;  word-spacing:5; letter-spacing: 2; color:white ; text-shadow: 5">
  <div class="heading">  

<h2 style=" padding:1.5%; font-family: Algerian; color:black;"><img src="images/cryptocurriencies-logo.jpg" style="height: 50px; padding-left: 2%; width: 100px;">
<b>ANALYSIS</b></></h2>
</div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>


        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mr-auto" style="text-align:right;">
            <li class="nav-item active">
              
                <a href="homepage.php" class="nav-link pl-0" style="text-align:left; color: white;  font-family:arial ;">Home</a>
              
            </li>

            <li class="nav-item"><a href="reg-about.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">About</a></li>

            <li class="nav-item"><a href="reg-stock.php" class="nav-link" style="text-align:left; color: white; word-spacing: 2px; font-family:arial ;">Stock Exchange</a></li>

            <li class="nav-item"><a href="portfolio.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Portfolio</a></li>

            <li class="nav-item"><a href="reg-news.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">News</a></li>

            <li class="nav-item"><a href="reg-cryptocurrency.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Crypto-Currency</a></li>

            <li class="nav-item"><a href="reg-where_to_invest.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Analysis</a></li>

            <li class="nav-item"><a href="Logout.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Logout</a></li>

          </ul>
        </div>
      </div>
    </nav>
<!-- TradingView Widget BEGIN -->
<h4 style="padding:3%; word-spacing: 1.5px; font: Arial;" >Our WHERE-TO-INVEST policy shows top 5 gaining, losing and active stocks for the day. We update on basis of real-time current market activity, so they always show the most relevant stocks.
Our data Analysist Team Works Day and Night to Bring Your The Best Possible Stocks For you To Invest with Us.</h4>
<div class="tradingview-widget-container">

  <div class="tradingview-widget-container__widget"></div>
  
  <span class="blue-text" style="align-items: center; padding: 10%">Cryptocurrency Market</span></a></div>

  <h3 style="text-align: center; color: black; font-family:arial ; letter-spacing: 2;"><span>STOCK OF DAY</span></h3>

<section style="padding-left: 10%; padding-right: 10%; padding-top: 2%; padding-bottom: 3%;">
<!-- TradingView Widget BEGIN -->
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://in.tradingview.com/markets/stocks-india/market-movers-gainers/" rel="noopener" target="_blank"><span class="blue-text">Stock Market</span></a> by TradingView</div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js" async>
  {
  "colorTheme": "light",
  "dateRange": "12m",
  "exchange": "BSE",
  "showChart": true,
  "locale": "in",
  "largeChartUrl": "",
  "isTransparent": true,
 "width": "100%",
  "height": "80%",
  "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
  "plotLineColorFalling": "rgba(33, 150, 243, 1)",
  "gridLineColor": "rgba(240, 243, 250, 1)",
  "scaleFontColor": "rgba(120, 123, 134, 1)",
  "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
  "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
  "symbolActiveColor": "rgba(33, 150, 243, 0.12)"
}
  </script>
</div>
<!-- TradingView Widget END -->
  </script>
  </section>
</div>
<footer style="background-color: black; padding:5%; text-align: center;">
  Want to know more about crypto curriencies <a href="cry_about.html">click me!</a> 
</footer>
</body>