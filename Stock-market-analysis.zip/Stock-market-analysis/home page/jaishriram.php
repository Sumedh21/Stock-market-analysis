<?php
session_start();
echo $_SESSION["username"];
$x = $_SESSION["username"];

;
?>