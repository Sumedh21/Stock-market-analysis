<?php
session_start();
?>
  <head>
    <title>BSE</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>





<body style=" background-color:black; background-size: 100% 100%;">

  <section style="background-color: black;  word-spacing:5; letter-spacing: 2; color:white ; text-shadow: 5">
  <div class="heading">  

<h2 style=" padding:1.5%; font-family: Algerian; color:white;"><img src="images/stock-market-logo.jpg" style="height: 50px; padding-left: 2%; width: 100px;">
<b>Stock prices</b></></h2>
</div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>


        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mr-auto" style="text-align:right;">
            <li class="nav-item active">
              
                <a href="homepage.php" class="nav-link pl-0" style="text-align:left; color: white;  font-family:arial ;">Home</a>
              
            </li>

            <li class="nav-item"><a href="reg-about.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">About</a></li>

            <li class="nav-item active"><a href="reg-stock.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Stock</a></li>

            <!-- <li class="nav-item"><a href="nse.html" class="nav-link" style="text-align:left; color: white;  font-family:arial ;">NSE</a></li> -->

            <li class="nav-item"><a href="portfolio.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Portfolio</a></li>

            <li class="nav-item"><a href="reg-news.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">News</a></li>

            <li class="nav-item"><a href="reg-cryptocurrency.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Crypto-Currency</a></li>

            <li class="nav-item"><a href="reg-where_to_invest.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Analysis</a></li>

            <li class="nav-item"><a href="Logout.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Logout</a></li>

          </ul>
        </div>
      </div>
    </nav>
<!--
 <h3 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2;"><span><a href="nse.html">NSE</a></span></h3>
  <h3 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2;"><span><a href="commodities.html">COMMMODITIES</a></span></h3>
   <h3 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2;"><span><a href="homepage.html">HOME</a></span></h3>
    <h3 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2;"><span><a href="news.html">NEWS</a></span></h3>
     <h3 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2;"><span><a href="#">EXTRA</a></span></h3>
-->
  </section>

  <h3 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2; padding-top:4%; "><span>BSE</span></h3>

<section style="padding-top: 2%; padding-right: 10%; padding-left: 10%; padding-bottom: 3%; background-color: ;" >
<div class="tradingview-widget-container">
  
  <div class="tradingview-widget-container__widget"></div>
  
  <div class="tradingview-widget-copyright"><a href="https://in.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Market Data</span></a> by TradingView</div>

  

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
  {
  "colorTheme": "dark",
  "dateRange": "12m",
  "showChart": true,
  "exchange": "BSE",
  "locale": "in",
  "largeChartUrl": "www.tradingview.com/chart/",
  "isTransparent": true,
  "width": "100%",
  "height": "80%",
  "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
  "plotLineColorFalling": "rgba(33, 150, 243, 1)",
  "gridLineColor": "rgba(233, 233, 234, 1)",
  "scaleFontColor": "rgba(120, 123, 134, 1)",
  "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
  "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
  "symbolActiveColor": "rgba(33, 150, 243, 0.12)",
  "tabs": [
    {
      "title": "Indices",
      "symbols": [
        {
          "s": "BSE:RELIANCE"
        },
        {
          "s": "BSE:YESBANK"
        },
        {
          "s": "BSE:SBIN"
        },
        {
          "s": "BSE:BANKBARODA"
        },
        {
          "s": "BSE:FEDERALBNK"
        },
        {
          "s": "BSE:DIVISLAB"
        },
        {
          "s": "BSE:SPICEJET"
        },
        {
          "s":"BSE:TCS"
        },
        {
          "s":"BSE:IBULHSGFIN"
        },
        {
          "s":"BSE:HDFC"
        },
        {
          "s":"BSE:ITC"
        },
        {
          "s":"BSE:HDFCBANK"
        },
        {
          "s":"BSE:KOTAKBANK"
        },
        {
          "s":"BSE:TATAMOTORS"
        },
        {
          "s":"BSE:AXISBANK"
        },
        {
          "s":"BSE:BANKINDIA"
        },
        {
          "s":"BSE:ICICIBANK"
        },

        {
          "s":"BSE:MARUTI"
        },

        {
          "s":"BSE:IONEXCHANG"
        },
        {
          "s":"BSE:IDEA"
        },
        {
          "s":"BSE:BAJFINANCE"
        },

        {
          "s":"BSE:ASIANPAINT"
        },

        {
          "s":"BSE:ASHOKLEY"
        },
        {
          "s":"BSE:HINDUNILVR"
        },
        {
          "s":"BSE:INDIGO"
        },

        {
          "s":"BSE:PNB"
        },
        {
          "s":"BSE:M_M"
        },
        {
          "s":"BSE:AVANTI"
        },
        {
          "s":"BSE:HDFCLIFE"
        },
        {
          "s":"BSE:WIPRO"
        },
        {
          "s":"BSE:BATAINDIA"
        },
        {
          "s":"BSE:FORCEMOT"
        },

        {
          "s":"BSE:TATASTEEL"
        },

        {
          "s":"BSE:BRITANNIA"
        },

        {
          "s":"BSE:INDUSINDBK"
        },

        {
          "s":"BSE:BERGEPAINT"
        },

        {
          "s":"BSE:TITAN"
        },

        {
          "s":"BSE:BHARTIARTL"
        },

        {
          "s":"BSE:RELINFRA"
        },

        {
          "s":"BSE:LT"
        }


      ],
      "originalTitle": "Indices"
    }
    ]
  }</script></div>
  </section>
</body>
    <!--
    {
      "title": "Commodities",
      "symbols": [
        {
          "s": "CME_MINI:ES1!",
          "d": "E-Mini S&P"
        },
        {
          "s": "CME:6E1!",
          "d": "Euro"
        },
        {
          "s": "COMEX:GC1!",
          "d": "Gold"
        },
        {
          "s": "NYMEX:CL1!",
          "d": "Crude Oil"
        },
        {
          "s": "NYMEX:NG1!",
          "d": "Natural Gas"
        },
        {
          "s": "CBOT:ZC1!",
          "d": "Corn"
        }
      ],
      "originalTitle": "Commodities"
    },
    {
      "title": "Bonds",
      "symbols": [
        {
          "s": "CME:GE1!",
          "d": "Eurodollar"
        },
        {
          "s": "CBOT:ZB1!",
          "d": "T-Bond"
        },
        {
          "s": "CBOT:UB1!",
          "d": "Ultra T-Bond"
        },
        {
          "s": "EUREX:FGBL1!",
          "d": "Euro Bund"
        },
        {
          "s": "EUREX:FBTP1!",
          "d": "Euro BTP"
        },
        {
          "s": "EUREX:FGBM1!",
          "d": "Euro BOBL"
        }
      ],
      "originalTitle": "Bonds"
    },
    {
      "title": "Forex",
      "symbols": [
        {
          "s": "FX:EURUSD"
        },
        {
          "s": "FX:GBPUSD"
        },
        {
          "s": "FX:USDJPY"
        },
        {
          "s": "FX:USDCHF"
        },
        {
          "s": "FX:AUDUSD"
        },
        {
          "s": "FX:USDCAD"
        }
      ],
      "originalTitle": "Forex"
    }
  ]
}
  </script>
</div>
 TradingView Widget END -->

<!-- TradingView Widget BEGIN 
<div class="tradingview-widget-container">
  <div class="tradingview-widget-container__widget"></div>
  <div class="tradingview-widget-copyright"><a href="https://www.tradingview.com/markets/stocks-india/market-movers-gainers/" rel="noopener" target="_blank"><span class="blue-text">Stock Market</span></a> by TradingView</div>
  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-hotlists.js" async>
  {
  "colorTheme": "light",
  "dateRange": "12m",
  "exchange": "BSE",
  "showChart": true,
  "locale": "en",
  "largeChartUrl": "",
  "isTransparent": false,
  "width": "400",
  "height": "600",
  "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
  "plotLineColorFalling": "rgba(33, 150, 243, 1)",
  "gridLineColor": "rgba(240, 243, 250, 1)",
  "scaleFontColor": "rgba(120, 123, 134, 1)",
  "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
  "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
  "symbolActiveColor": "rgba(33, 150, 243, 0.12)"
}
  </script>
</div>
TradingView Widget END -->




<!--
<script>

  function updateQuotes(data) {
   for (ticker in quote) {
    var symbol = quote[ticker];
  
    document.write('<div>Price of ' + ticker + ' : Close -  ' + symbol['Last'] + '</div>');
  document.write('<div>Price of ' + ticker + ' : Low -  ' + symbol['Low'] + '</div>');
  document.write('<div>Price of ' + ticker + ' : High -  ' + symbol['High'] + '</div>');
  document.write('<div>Price of ' + ticker + ' :Open - ' + symbol['Open'] + '</div>');
  
   }
  }
 </script> -->

<!-- TradingView Widget END -->

<!-- TradingView Widget BEGIN -->