<?php
session_start();
?>

<html>
<head>
	<style type="text/css">
		body{
			background-image:url("xyz.jpeg");
			height:100%;
			width:100%: 
			background-position: center;
  			background-repeat: no-repeat;
 			background-size: cover;
			background-attachment: fixed;
		}
		p{
			color:black;
			border-spacing: 5;
			font-size: 20;
		}
		h2{
			color:999933;
		}
</style>
<script src="D:\jquery-3.4.1.js"> 
</script> 
</head>
<body style=""><td><tr>
<h4>

	<a href="homepage.php"><button style="background-color: skyblue; border-radius: 9;"><hover>Home</hover></button></a>
	
	<a href="reg-stock.php"><button style="background-color: skyblue; border-radius: 9;">Commodities</button></a>
	
	<a href="portfolio.php"><button style="background-color: skyblue; border-radius: 9;">Portofolio</button></a></h4>


<p1>
<h1 align="center" style="color:">Cryptocurrency</h2></tr></td>

<td><tr><p3>
<h2 style="background-color:  lightgreen;"  onclick="myFunction()" align="center">What is cryptocurrency?</h2></p3>
</tr>

<script>
function myFunction() {
  var x = document.getElementById("myDIV");
  x.style.display === "block";
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>

<tr>
<p id="myDIV">A digital currency in which encryption techniques are used to regulate the generation of units of currency and verify the transfer of funds, operating independently of a central bank.</p>
</tr>



<tr>
<h2 style="background-color:  lightgreen;" align="center" onclick="myFunction()">How does it works?</h2></tr><tr>
<p>Cryptocurrency is an encrypted, decentralized digital currency transferred between peers and confirmed in a public ledger via a process known as mining.
	Public Ledgers: All confirmed transactions from the start of a cryptocurrency's creation are stored in a public ledger. The identities of the coin owners are encrypted, and the system uses other cryptographic techniques to ensure the legitimacy of record keeping. The ledger ensures that corresponding digital wallets can calculate an accurate spendable balance. Also, new transactions can be checked to ensure that each transaction uses only coins currently owned by the spender. Bitcoin calls this public ledger a transaction block chain.
	Transactions: A transfer of funds between two digital wallets is called a transaction. That transaction gets submitted to a public ledger and awaits confirmation. Wallets use an encrypted electronic signature when a transaction is made. The signature is an encrypted piece of data called a cryptographic signature and it provides a mathematical proof that the transaction came from the owner of the wallet. The confirmation process takes a bit of time (ten minutes for bitcoin) while miners mine. Mining confirms the transactions and adds them to the public ledger.

Mining: Mining is the process of confirming transactions and adding them to a public ledger. To add a transaction to the ledger, the miner must solve an increasingly-complex computational problem (like a mathematical puzzle). Mining is open source so that anyone can confirm the transaction. The first miner to solve the puzzle adds a block of transactions to the ledger. The way in which transactions, blocks, and the public blockchain ledger work together ensure that no one individual can easily add or change a block at will. Once a block is added to the ledger, all correlating transactions are permanent, and they add a small transaction fee to the miner's wallet (along with newly created coins). The mining process is what gives value to the coins and is known as a proof-of-work system.
</p></tr>


<tr>
<h2 style="background-color:  lightgreen;" align="center" onclick="myFunction1()"> Can cryptocurrency be converted into cash?</h2> </tr><tr>
<p id="myDIV1">1. Choose conversion or exchange service.<br>
2. Create an account.<br>
3. Make cryptocurrency conversion with the cheapest service.<br>
4. Check the security of the service.<br>
5. Select a quick conversion service.<br>
6.  Withdraw your cryptos.<br>
7. Put your cryptos on a card.<br>
8. Transfer the cryptos to the electronic wallet.<br></p></tr>
<script>
function myFunction1() {
  var x = document.getElementById("myDIV1");
  x.style.display === "block";
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
</script>
<tr>
<h2 style="background-color:  lightgreen;" align="center"onclick="myFunction()"> What is bitcoin? </h2></tr><tr>
<p>
Bitcoin is a cryptocurrency. It is a decentralized digital currency without a central bank or single administrator that can be sent from user to user on the peer-to-peer bitcoin network without the need for intermediaries.</p></tr>

<tr>
<h2 style="background-color:  lightgreen;" align="center" onclick="myFunction()"> What is bitcoin minning? </h2></tr><tr>
	<p>
		Mining is the process of confirming transactions and adding them to a public ledger. To add a transaction to the ledger, the miner must solve an increasingly-complex computational problem (like a mathematical puzzle). Mining is open source so that anyone can confirm the transaction. The first miner to solve the puzzle adds a block of transactions to the ledger. The way in which transactions, blocks, and the public blockchain ledger work together ensure that no one individual can easily add or change a block at will. Once a block is added to the ledger, all correlating transactions are permanent, and they add a small transaction fee to the miner's wallet (along with newly created coins). The mining process is what gives value to the coins and is known as a proof-of-work system.
	</p></tr>

<tr><h2 style="background-color:  lightgreen;" align="center" onclick="myFunction()"> Why is bitcoin minning is practised? </h2></tr><tr>
<p>
	The purpose of Bitcoin mining is to make secured network transactions between two users without any involvement of third party like government, bank, or any other authority. Bitcoin mining provides the Bitcoin value and miners solve the cryptographic problems in order to place a new block.
</p></tr>
</td>

<a href="reg-about.php">
<button style="background-color: skyblue; border-radius: 9;">About</button>
</a>
<p></p>
</body>
</html>