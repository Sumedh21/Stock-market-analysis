<?php
session_start();
?>
<head>
    <script src="angular.min.js"></script>
    <title>PORTFOLIO</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Nunito+Sans:300,400,600,700,800,900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">

<style type="text/css">
              th { 
                background-color:green; 
                Color:white; 
            } 
            th, td { 
                width:150px; 
                text-align:center; 
                border:1px solid black; 
                padding:5px;
            }
</style>

  </head>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script src= "http://ajax.googleapis.com/ajax/libs/angularjs/1.2.26/angular.min.js"></script>



<!-- nav started -->

<body style=" background-color: white; background-size: 100% 100%;">
  <form action="portfolio_insert.php" method="POST">

  <section style="background-color:white;  word-spacing:5; letter-spacing: 2; color:black ; text-shadow: 5">
  <div class="heading">  

<h2 style=" padding:1.5%; font-family: TimesNewRoman; color: black;"><img src="images/portfolio.jpg" style="height: 50px; padding-left: 2%; width: 100px;">
<b>Portfolio</b></></h2>
</div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark ftco-navbar-light" id="ftco-navbar">
      <div class="container d-flex align-items-center">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
          <span class="oi oi-menu"></span> Menu
        </button>


        <div class="collapse navbar-collapse" id="ftco-nav">
          <ul class="navbar-nav mr-auto" style="text-align:right;">
            <li class="nav-item active">
              
                <a href="homepage.php" class="nav-link pl-0" style="text-align:left; color: white;  font-family:arial ;">Home</a>
              
            </li>

            <li class="nav-item"><a href="reg-about.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">About</a></li>

            <li class="nav-item"><a href="reg-nse.php" class="nav-link" style="text-align:left; color: white;  font-family:arial ;">NSE</a></li>

            <li class="nav-item"><a href="portfolio.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Portfolio</a></li>

            <li class="nav-item"><a href="reg-news.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">News</a></li>

            <li class="nav-item"><a href="reg-cryptocurrency.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Crypto</a></li>

            <li class="nav-item"><a href="reg-where_to_invest.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Analysis</a></li>

            <li class="nav-item"><a class="nav-link"
              style="text-align:left; color: white;  font-family:arial ;">Logged in as - <?php echo $_SESSION["username"]; ?>

            <li class="nav-item"><a href="Logout.php" class="nav-link"style="text-align:left; color: white;  font-family:arial ;">Logout</a></li>

          </ul>
        </div>
      </div>
    </nav>
  </section>
<!-- nav ended-->

<h4>
  <?php
  echo "New record created successfully";
  ?>
</h4>


 <h4 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2; padding-top:4%; "></h4>
    <section >
        <span>
             <script src="angular.min.js"></script>
                  <div class="Portfolio_table">
                      <table style="text-align: center;" style="padding: 5%; grid-row-gap: 5%; border:0; border-spacing: 30px" align="center" >
                            <tr style="word-spacing: 50px;">
                              <th>Stock_name</th>
                              <th>Date</th>
                              <th>Quantity</th>
                              <th>Price</th>
                              <th>Total</th>
                              <th>Description</th>
                            </tr>
        <tr style="padding: 3%">
                   <td><select placeholder="name" name="stk_name" required >
            <option select hidden value="stock"></option>
            <OPTION value="BSE:RELIANCE">BSE:RELIANCE</option>
            <OPTION value="BSE:YESBANK">BSE:YESBANK</option>
            <OPTION value="BSE:SBIN">BSE:SBIN</option>
            <OPTION value="BSE:BANKBARODA">BSE:BANKBARODA</option>
            <OPTION value="BSE:FEDERALBNK">BSE:FEDERALBNK</option>
            <OPTION value="BSE:DIVISLAB">BSE:DIVISLAB</option>
            <OPTION value="BSE:SPICEJET">BSE:SPICEJET</option>
            <OPTION value="BSE:TCS">BSE:TCS</option>
            <OPTION value="BSE:IBULHSGFIN">BSE:IBULHSGFIN</option>
            <OPTION value="BSE:HDFC">BSE:HDFC</option>
            <OPTION value="BSE:ITC">BSE:ITC</option>
            <OPTION value="BSE:HDFCBANK">BSE:HDFCBANK</option>
            <OPTION value="BSE:KOTAKBANK">BSE:KOTAKBANK</option>
            <OPTION value="BSE:TATAMOTORS">BSE:TATAMOTORS</option>
            <OPTION value="BSE:AXISBANK">BSE:AXISBANK</option>
            <OPTION value="BSE:BANKINDIA">BSE:BANKINDIA</option>
            <OPTION value="BSE:ICICBANK">BSE:ICICBANK</option>
            <OPTION value="BSE:MARUTI">BSE:MARUTI</option>
            <OPTION value="BSE:IONEXCHANG">BSE:IONEXCHANG</option>
            <OPTION value="BSE:IDEA">BSE:IDEA</option>
            <OPTION value="BSE:BAJFINANCE">BSE:BAJFINANCE</option>
            <OPTION value="BSE:ASIANPAINT">BSE:ASIANPAINT</option>
            <OPTION value="BSE:ASHOKLEY">BSE:ASHOKLEY</option>
            <OPTION value="BSE:HINDUNILVR">BSE:HINDUNILVR</option>
            <OPTION value="BSE:INDIGO">BSE:INDIGO</option>
            <OPTION value="BSE:PNB">BSE:PNB</option>
            <OPTION value="BSE:M_M">BSE:M_M</option>
            <OPTION value="BSE:AVANTI">BSE:AVANTI</option>
            <OPTION value="BSE:HDFCLIFE">BSE:HDFCLIFE</option>
            <OPTION value="BSE:WIPRO">BSE:WIPRO</option>
            <OPTION value="BSE:BATAINDIA">BSE:BATAINDIA</option>
            <OPTION value="BSE:FORCEMOT">BSE:FORCEMOT</option>
            <OPTION value="BSE:TATASTEEL">BSE:TATASTEEL</option>
            <OPTION value="BSE:BRITANNIA">BSE:BRITANNIA</option>
            <OPTION value="BSE:INDUSINDBK">BSE:INDUSINDBK</option>
            <OPTION value="BSE:BERGEPAINT">BSE:BERGEPAINT</option>
            <OPTION value="BSE:TITAN">BSE:TITAN</option>
            <OPTION value="BSE:BHARTIARTL">BSE:BHARTIARTL</option>
            <OPTION value="BSE:RELINFRA">BSE:RELINFRA</option>
            <OPTION value="BSE:LT">BSE:LT</option>
          </select>
        </td>
          <td> <input type="date" name="date" required></td>
          <td> <input type="number" id="in1" name="quantity" required></td>
          <td> <input type="number" id="in2" name="price" required></td> 
          <td><button type="button" onclick="getText3()"><input type="number" id="in3" name="total" required></button></td>
          <td> <input type="text" name="description" required></td>
        </tr>
 
  <p style="text-align: center; padding: 3%">
  <script>
   function getText3(){
      var in1=document.getElementById('in1').value;
      var in2=document.getElementById('in2').value;
      var in3=in1*in2;
      document.getElementById('in3').value=in3;
   }
</script>
  </table>
  <div style="text-align: center; padding-top: 2%">  <input type="submit" style="" name="submit" style="border-style: dotted;" value="Add Stock" >
   </div>

     <!-- for delete 
     <h4 style="text-align: center; color: white;  font-family:arial ; letter-spacing: 2; padding-top:2%; "></h4>
    <section >
        <span>
             <script src="angular.min.js"></script>
                  <div class="Portfolio_table">
                      <table style="text-align: center;" style="padding: 5%; grid-row-gap: 5%; border-spacing: 30px;" align="center" >
                            <tr style="word-spacing: 50px;">
                              <th>Stock_name</th>

                            </tr>
        <tr style="padding: 3%; border-color: white;">
                   <td><select placeholder="name" name="stk_name" required >
            <option select hidden value="stock"></option>
            <OPTION value="BSE:RELIANCE">BSE:RELIANCE</option>
            <OPTION value="BSE:YESBANK">BSE:YESBANK</option>
            <OPTION value="BSE:SBIN">BSE:SBIN</option>
            <OPTION value="BSE:BANKBARODA">BSE:BANKBARODA</option>
            <OPTION value="BSE:FEDERALBNK">BSE:FEDERALBNK</option>
            <OPTION value="BSE:DIVISLAB">BSE:DIVISLAB</option>
            <OPTION value="BSE:SPICEJET">BSE:SPICEJET</option>
            <OPTION value="BSE:TCS">BSE:TCS</option>
            <OPTION value="BSE:IBULHSGFIN">BSE:IBULHSGFIN</option>
            <OPTION value="BSE:HDFC">BSE:HDFC</option>
            <OPTION value="BSE:ITC">BSE:ITC</option>
            <OPTION value="BSE:HDFCBANK">BSE:HDFCBANK</option>
            <OPTION value="BSE:KOTAKBANK">BSE:KOTAKBANK</option>
            <OPTION value="BSE:TATAMOTORS">BSE:TATAMOTORS</option>
            <OPTION value="BSE:AXISBANK">BSE:AXISBANK</option>
            <OPTION value="BSE:BANKINDIA">BSE:BANKINDIA</option>
            <OPTION value="BSE:ICICBANK">BSE:ICICBANK</option>
            <OPTION value="BSE:MARUTI">BSE:MARUTI</option>
            <OPTION value="BSE:IONEXCHANG">BSE:IONEXCHANG</option>
            <OPTION value="BSE:IDEA">BSE:IDEA</option>
            <OPTION value="BSE:BAJFINANCE">BSE:BAJFINANCE</option>
            <OPTION value="BSE:ASIANPAINT">BSE:ASIANPAINT</option>
            <OPTION value="BSE:ASHOKLEY">BSE:ASHOKLEY</option>
            <OPTION value="BSE:HINDUNILVR">BSE:HINDUNILVR</option>
            <OPTION value="BSE:INDIGO">BSE:INDIGO</option>
            <OPTION value="BSE:PNB">BSE:PNB</option>
            <OPTION value="BSE:M_M">BSE:M_M</option>
            <OPTION value="BSE:AVANTI">BSE:AVANTI</option>
            <OPTION value="BSE:HDFCLIFE">BSE:HDFCLIFE</option>
            <OPTION value="BSE:WIPRO">BSE:WIPRO</option>
            <OPTION value="BSE:BATAINDIA">BSE:BATAINDIA</option>
            <OPTION value="BSE:FORCEMOT">BSE:FORCEMOT</option>
            <OPTION value="BSE:TATASTEEL">BSE:TATASTEEL</option>
            <OPTION value="BSE:BRITANNIA">BSE:BRITANNIA</option>
            <OPTION value="BSE:INDUSINDBK">BSE:INDUSINDBK</option>
            <OPTION value="BSE:BERGEPAINT">BSE:BERGEPAINT</option>
            <OPTION value="BSE:TITAN">BSE:TITAN</option>
            <OPTION value="BSE:BHARTIARTL">BSE:BHARTIARTL</option>
            <OPTION value="BSE:RELINFRA">BSE:RELINFRA</option>
            <OPTION value="BSE:LT">BSE:LT</option>
          </select>
        </td>
  </table>
  <div style="text-align: center; padding-top: 2%">  <input type="submit" name="Delete"  value="Delete Stock" >
   
   end delete -->
       
    </div>

    </span>
  </section>
</form>
</p></body>
<br>
<h4>&nbsp;&nbsp;Your Saved Stock: 
  <br>
</h4> 
<h5>



<?php

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "snap";

$stock_name = $_POST['stk_name'];
$date=$_POST['date'];
$quantity= $_POST['quantity'];
$price = $_POST['price'];
$total= $_POST['total'];
$description= $_POST['description'];

$username = $_SESSION["username"];




 $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    
$sql = "INSERT INTO user_portfolio(username,stk_name,stk_date,stk_quantity,stk_price,total,description) VALUES 
('$username','$stock_name','$date','$quantity','$price','$total','$description')";


if ($conn->query($sql) === TRUE) 
{
    echo"";
} 
else
{
    echo "Error: " . $sql . "<br>" . $conn->error;
}

//delete
$delete = new mysqli($host, $dbUsername, $dbPassword, $dbname);
$sqll = "DELETE FROM `user_portfolio` WHERE stk_name='$stock_name'";


if ($delete->query($sqll) === TRUE) 
{
    echo"";
} 
else
{
    echo "Error: " . $sqll . "<br>" . $delete->error;
}
//delete_end

$ssqql = "SELECT * FROM user_portfolio WHERE username = '$username' ";
$response = @mysqli_query($conn, $ssqql);

if($response){
    echo "<center><table>
    <tr>
    <td>STOCK NAME</td>
    <td>DATE</td>
    <td>QUANTITY</td>
    <td>PRICE</td>
    <td>TOTAL</td>
    <td>DESCRIPTION</td>
    </tr>";
  while($row = mysqli_fetch_array($response))
   
  {

echo "<tr>";
//$row['id'].'<br>'.

echo "<td>".$row['stk_name'].'   &nbsp;&nbsp;   '."</td>";
echo "<td>".$row['stk_date'].'&nbsp;&nbsp;&nbsp;&nbsp; '."</td>";
echo "<td>".$row['stk_quantity'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'."</td>";
echo "<td>".$row['stk_price'].'  &nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;  '."</td>";
echo "<td>".$row['total'].' &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;' .' - '."</td>";
echo "<td>".$row['description']."</td>";
echo"</tr>";
//echo nl2br("\n");
}
echo"</center>";
echo"</table>";
}
else {

echo "Couldn't issue database query<br />";

echo mysqli_error($conn);

}



$conn->close();
?>





<h3 style="text-align: center; color: black;  font-family:arial ; letter-spacing: 2; padding-top:4%; "><span>BSE</span></h3>

<section style="padding-top: 2%; padding-right: 10%; padding-left: 10%; padding-bottom: 3%; background-color: ;" >
<div class="tradingview-widget-container">
  
  <div class="tradingview-widget-container__widget"></div>
  
  <div class="tradingview-widget-copyright"><a href="https://in.tradingview.com" rel="noopener" target="_blank"><span class="blue-text">Market Data</span></a> by TradingView</div>

  

  <script type="text/javascript" src="https://s3.tradingview.com/external-embedding/embed-widget-market-overview.js" async>
  {
  "colorTheme": "light",
  "dateRange": "12m",
  "showChart": true,
  "exchange": "BSE",
  "locale": "in",
  "largeChartUrl": "www.tradingview.com/chart/",
  "isTransparent": true,
  "width": "100%",
  "height": "80%",
  "plotLineColorGrowing": "rgba(33, 150, 243, 1)",
  "plotLineColorFalling": "rgba(33, 150, 243, 1)",
  "gridLineColor": "rgba(233, 233, 234, 1)",
  "scaleFontColor": "rgba(120, 123, 134, 1)",
  "belowLineFillColorGrowing": "rgba(33, 150, 243, 0.12)",
  "belowLineFillColorFalling": "rgba(33, 150, 243, 0.12)",
  "symbolActiveColor": "rgba(33, 150, 243, 0.12)",
  "tabs": [
    {
      "title": "Indices",
      "symbols": [
        {
          "s": "BSE:RELIANCE"
        },
        {
          "s": "BSE:YESBANK"
        },
        {
          "s": "BSE:SBIN"
        },
        {
          "s": "BSE:BANKBARODA"
        },
        {
          "s": "BSE:FEDERALBNK"
        },
        {
          "s": "BSE:DIVISLAB"
        },
        {
          "s": "BSE:SPICEJET"
        },
        {
          "s":"BSE:TCS"
        },
        {
          "s":"BSE:IBULHSGFIN"
        },
        {
          "s":"BSE:HDFC"
        },
        {
          "s":"BSE:ITC"
        },
        {
          "s":"BSE:HDFCBANK"
        },
        {
          "s":"BSE:KOTAKBANK"
        },
        {
          "s":"BSE:TATAMOTORS"
        },
        {
          "s":"BSE:AXISBANK"
        },
        {
          "s":"BSE:BANKINDIA"
        },
        {
          "s":"BSE:ICICIBANK"
        },

        {
          "s":"BSE:MARUTI"
        },

        {
          "s":"BSE:IONEXCHANG"
        },
        {
          "s":"BSE:IDEA"
        },
        {
          "s":"BSE:BAJFINANCE"
        },

        {
          "s":"BSE:ASIANPAINT"
        },

        {
          "s":"BSE:ASHOKLEY"
        },
        {
          "s":"BSE:HINDUNILVR"
        },
        {
          "s":"BSE:INDIGO"
        },

        {
          "s":"BSE:PNB"
        },
        {
          "s":"BSE:M_M"
        },
        {
          "s":"BSE:AVANTI"
        },
        {
          "s":"BSE:HDFCLIFE"
        },
        {
          "s":"BSE:WIPRO"
        },
        {
          "s":"BSE:BATAINDIA"
        },
        {
          "s":"BSE:FORCEMOT"
        },

        {
          "s":"BSE:TATASTEEL"
        },

        {
          "s":"BSE:BRITANNIA"
        },

        {
          "s":"BSE:INDUSINDBK"
        },

        {
          "s":"BSE:BERGEPAINT"
        },

        {
          "s":"BSE:TITAN"
        },

        {
          "s":"BSE:BHARTIARTL"
        },

        {
          "s":"BSE:RELINFRA"
        },

        {
          "s":"BSE:LT"
        }


      ],
      "originalTitle": "Indices"
    }
    ]
  }</script></div>
  </section>
</body>
