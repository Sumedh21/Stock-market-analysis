<?php

$host = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbname = "snap";

$password= $_POST['password'];

$username = $_POST["username"];




 $conn = new mysqli($host, $dbUsername, $dbPassword, $dbname);

    
$sql = "INSERT INTO login(username,password) VALUES 
('$username','$password')";


if ($conn->query($sql) === TRUE) 
{
      echo '<script language="javascript">';
  echo 'alert(successfully registered)';  //not showing an alert box.
  echo '</script>';
    
    header("location: Login.php");
} 
else
{
    echo "Error: " . $sql . "<br>" . $conn->error;
}



$conn->close();
?>


